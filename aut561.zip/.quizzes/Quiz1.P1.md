# Quiz 1 – Part 1 (15% of course score)

**Topic:** AUT561 Weeks 1–4 (IoT for Embedded/PLC, Dev Environment, Programming Foundations, Python Basics)

**Total: 15 marks** (each question shows mark allocation)

---

## Questions

### 1.

In industrial IoT systems, does IoT **replace** PLCs, or **complement** them? State the correct relationship in one sentence. **(1 mark)**

---

### 2.

In the development environment for this course, which command is used to verify that Python is installed and accessible from the command line? **(1 mark)**

---

### 3.

True or False: A **Python virtual environment (venv)** isolates project-specific packages and versions from the system Python, helping avoid conflicts between projects. **(1 mark)**

---

### 4.

In one sentence each: what is the role of a **sensor** and what is the role of an **actuator** in an automation or IoT system? **(2 marks)**

---

### 5.

Consider the following Python code:

```python
if temperature > 40:
    alarm = True
else:
    alarm = False
```

What type of logic does this implement? What problem can occur when the sensor value has **noise** near the threshold (e.g. 40)? **(2 marks)**

---

### 6.

Given the Python code:

```python
readings = [22.5, 23.1, 24.0, 22.8, 23.5]
average = sum(readings) / len(readings)
```

What is the value of `average`? Which Python data type is most appropriate for the elements of `readings` (e.g. for sensor values)? **(2 marks)**

---

### 7.

In **Node-RED**, which node is typically used to **manually trigger or simulate input data** (e.g. sensor values) during testing? **(1 mark)**

---

### 8.

Consider this Python code:

```python
reading = {
    "name": "TempSensor-01",
    "value": 25.5,
    "unit": "°C",
}
```

What is the name of this data structure in Python? What is the difference between `reading["value"]` and `reading.get("value")` when the key exists? **(2 marks)**

---

### 9.

True or False: **Hysteresis** (e.g. turn fan ON at 48°C and OFF at 40°C) is used to reduce rapid switching (chattering) when the sensor value hovers near a single threshold. **(1 mark)**

---

### 10.

In the following Python code, what is the purpose of `raise` and `except`?

```python
try:
    value = float(input_str)
    if value < 0 or value > 100:
        raise ValueError("Out of range")
    return value
except ValueError as e:
    print("Error:", e)
    return None
```

**(2 marks)**

---

**End of Part 1 – Total: 15 marks (15% of course score)**
