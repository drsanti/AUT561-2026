# Quiz 1 – Part 2 (5% of course score)

**Topic:** AUT561 Quiz 1 – Coding tasks (Weeks 1–4). You may use AI tools to help write code. Only concepts from the Week 1–4 learning materials are assessed.

**Total: 5 marks** (each question shows mark allocation). Submit your code as specified for each question.

---

## Question 1

Write a **Python function** that takes a **list** of numbers (sensor readings) and a range `min_val`, `max_val`, and returns a **dictionary** with:

- `"average"`: the average of all readings
- `"min"`: the minimum value
- `"max"`: the maximum value
- `"count_in_range"`: the number of readings that lie within `min_val` and `max_val` (inclusive)

You may assume the list is non-empty. **(2 marks)**

**Submit:** One Python file (e.g. `q1_readings_stats.py`) with the function and a short test (e.g. `print`) using a sample list and range.

---

## Question 2

Implement **hysteresis** for a simple fan control in Python. Write a **function** that, given:

- `current_temp`: current temperature (float)
- `high_threshold`: turn fan **ON** when temp ≥ this (e.g. 48)
- `low_threshold`: turn fan **OFF** when temp ≤ this (e.g. 40)
- `fan_currently_on`: current fan state (bool: `True` = ON, `False` = OFF)

returns the **new fan state** (`True` or `False`) after applying hysteresis (fan ON only when temp ≥ high_threshold, OFF only when temp ≤ low_threshold; otherwise keep current state).

**(2 marks)**

**Submit:** One Python file (e.g. `q2_hysteresis.py`) with your function and at least one example call showing the result for a temperature and current state.

---

## Question 3

Write a **Python function** that builds a **sensor reading dictionary** from a sensor name (str), a **string** that should represent a numeric value, and a unit (str). The function must **convert** the value string to a number and **raise** an exception (e.g. `ValueError`) if the string is not a valid number. Write a short piece of code that calls this function inside **try/except** for both a valid and an invalid string, and prints the resulting dictionary or the error message. **(1 mark)**

**Submit:** One Python file (e.g. `q3_parse_reading.py`) containing the function and the try/except examples.

---

**End of Part 2 – Total: 5 marks (5% of course score)**
