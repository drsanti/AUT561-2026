# Quiz 1 – Part 2 – Model Answers (Sample Code)

**Topic:** AUT561 Quiz 1 – Coding tasks (Weeks 1–4)

---

## Question 1 (2 marks) – Readings statistics

```python
# q1_readings_stats.py

def get_readings_stats(readings, min_val, max_val):
    total = sum(readings)
    count = len(readings)
    count_in_range = sum(1 for r in readings if min_val <= r <= max_val)
    return {
        "average": total / count,
        "min": min(readings),
        "max": max(readings),
        "count_in_range": count_in_range,
    }

# Test
readings = [22.5, 23.1, 24.0, 22.8, 23.5]
stats = get_readings_stats(readings, 22, 24)
print(stats)
# e.g. {'average': 23.18, 'min': 22.5, 'max': 24.0, 'count_in_range': 5}
```

---

## Question 2 (2 marks) – Hysteresis fan control

```python
# q2_hysteresis.py

def next_fan_state(current_temp, high_threshold, low_threshold, fan_currently_on):
    if current_temp >= high_threshold:
        return True   # Fan ON
    if current_temp <= low_threshold:
        return False  # Fan OFF
    return fan_currently_on  # Keep current state

# Example: temp 45, fan currently OFF, high=48, low=40 -> stay OFF
result = next_fan_state(45, 48, 40, False)
print("Temp 45, fan OFF ->", result)  # False

# Temp 49 -> ON
result2 = next_fan_state(49, 48, 40, False)
print("Temp 49, fan OFF ->", result2)  # True

# Temp 42, fan ON -> stay ON (between 40 and 48)
result3 = next_fan_state(42, 48, 40, True)
print("Temp 42, fan ON ->", result3)  # True
```

---

## Question 3 (1 mark) – Parse sensor reading with try/except

```python
# q3_parse_reading.py

def parse_sensor_reading(name, value_str, unit):
    value = float(value_str)
    return {"name": name, "value": value, "unit": unit}

# Valid string
try:
    r1 = parse_sensor_reading("TempSensor-01", "25.5", "°C")
    print("Valid:", r1)
except ValueError as e:
    print("Error:", e)

# Invalid string
try:
    r2 = parse_sensor_reading("TempSensor-01", "invalid", "°C")
    print(r2)
except ValueError as e:
    print("Invalid:", e)
```

---

**End of Part 2 – Model Answers**
