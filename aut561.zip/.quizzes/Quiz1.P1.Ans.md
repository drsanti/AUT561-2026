# Quiz 1 – Part 1 – Answers

**Topic:** AUT561 Weeks 1–4

---

## 1. (1 mark)

IoT **complements** PLCs; it does not replace them. IoT extends PLC-based systems with connectivity, remote monitoring, data collection, and analytics while PLCs continue to provide deterministic real-time control and safety.

---

## 2. (1 mark)

**`python --version`** (or on some systems **`python3 --version`**). This command checks that Python is installed and shows the version.

---

## 3. (1 mark)

**True.** A virtual environment (venv) isolates project-specific packages and Python versions from the system installation, reducing conflicts between different projects.

---

## 4. (2 marks)

- **Sensor:** A sensor measures a physical quantity (e.g. temperature, pressure, position) and converts it into a signal or data that can be processed by a controller.
- **Actuator:** An actuator receives control commands and performs a physical action (e.g. turning a motor on/off, opening a valve, switching a relay).

---

## 5. (2 marks)

- **Type of logic:** **Threshold (comparison) logic** – alarm is True when temperature exceeds 40, otherwise False (similar to PLC conditional logic).
- **Problem with noise:** When the sensor value has **noise** near 40, the alarm can **rapidly switch True and False** (chattering). Using **hysteresis** (two thresholds: one to set alarm ON, one to set it OFF) reduces this.

---

## 6. (2 marks)

- **Value of `average`:** `sum(readings) / len(readings)` = (22.5+23.1+24.0+22.8+23.5)/5 = **23.18** (or 23.18 when rounded).
- **Data type for elements:** **`float`** is the most appropriate type for sensor values (decimal numbers like temperature).

---

## 7. (1 mark)

The **Inject** node. It is used to manually trigger or simulate input data (e.g. at a fixed interval or on button click) for testing flows.

---

## 8. (2 marks)

- **Data structure:** A **dictionary** (dict) – key–value pairs.
- **Difference:** When the key exists, both `reading["value"]` and `reading.get("value")` return the value (25.5). If the key were missing, `reading["value"]` would raise `KeyError`, while `reading.get("value")` would return `None` (no exception). So **`.get()`** is safer when the key might be absent.

---

## 9. (1 mark)

**True.** Hysteresis uses two thresholds (e.g. ON at 48°C, OFF at 40°C) so the fan does not switch rapidly when the temperature hovers near a single value.

---

## 10. (2 marks)

- **`raise`:** Used to signal an error when a condition is violated (here, when the value is out of range). It creates a `ValueError` and stops normal execution so the error can be handled.
- **`except`:** Runs when an exception occurs in the `try` block. It catches the error (here `ValueError`), prints the message, and returns `None`, so invalid input does not crash the program and execution can continue.

---

**End of Part 1 – Answers**
